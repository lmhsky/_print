from setuptools import setup

setup(name='lmhprint',
      version='0.1',
      description='random color print',
      url='https://github.com/lmhsky/_print',
      author='lmhsky',
      author_email='lmhtowork@gmail.com',
      license='MIT',
      packages=['lmhprint'])
